package com.example.utils

object Const {
}