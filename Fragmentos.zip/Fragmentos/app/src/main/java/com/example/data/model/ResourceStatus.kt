package com.example.data.model

enum class ResourceStatus {
    SUCCESS,
    ERROR,
    LOADING
}