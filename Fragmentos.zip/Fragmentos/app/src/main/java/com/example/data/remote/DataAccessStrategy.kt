package com.example.data.remote;

public class DataAccessStrategy {
}
