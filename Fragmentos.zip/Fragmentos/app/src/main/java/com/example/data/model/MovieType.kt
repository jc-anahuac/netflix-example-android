package com.example.data.model

enum class MovieType {

}