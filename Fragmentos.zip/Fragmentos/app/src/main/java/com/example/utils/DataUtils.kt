package com.example.utils

object DataUtils {
}