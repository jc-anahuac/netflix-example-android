package com.example.data.remote

interface ApiService {
}