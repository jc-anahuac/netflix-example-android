package com.example.data.entities;

import androidx.room.Database;

public class to {
}
