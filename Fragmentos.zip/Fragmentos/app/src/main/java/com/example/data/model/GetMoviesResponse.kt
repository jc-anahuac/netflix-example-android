package com.example.data.model

class GetMoviesResponse {
}